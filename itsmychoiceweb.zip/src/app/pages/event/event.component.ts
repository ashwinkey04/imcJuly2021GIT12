import { Component, OnInit } from "@angular/core";

@Component({
  selector: "ngx-event",
  template: `<router-outlet></router-outlet>`,
})
export class EventComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
