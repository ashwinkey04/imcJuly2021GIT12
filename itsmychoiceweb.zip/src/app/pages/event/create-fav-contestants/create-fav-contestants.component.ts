import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-create-fav-contestants',
  templateUrl: './create-fav-contestants.component.html',
  styleUrls: ['./create-fav-contestants.component.scss']
})
export class CreateFavContestantsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
