import { Component, OnInit } from "@angular/core";

@Component({
  selector: "ngx-rank-view",
  template: `<router-outlet></router-outlet>`,
})
export class RankViewComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
