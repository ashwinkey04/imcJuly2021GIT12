import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-contestants',
  template: `<router-outlet></router-outlet>`,
})
export class ContestantsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
