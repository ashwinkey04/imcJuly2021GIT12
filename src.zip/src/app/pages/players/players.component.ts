import { Component, OnInit } from "@angular/core";

@Component({
  selector: "ngx-players",
  template: `<router-outlet></router-outlet>`,
})
export class PlayersComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
